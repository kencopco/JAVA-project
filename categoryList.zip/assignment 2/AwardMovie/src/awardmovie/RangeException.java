/*
 Author: Jiacheng Sun
 E-mail: jzs375@psu.edu
 Course: CMPSC 221
 Assignment: Programming Assignment 2
 Due date: 2/27/2018
 File: AwardMovie.java
 Purpose: Java application that implements a driver to demonstrate the
 functionality of a base class (Movie) and its derived class
 (AwardWinningMovie)
 Compiler/IDE: Java SE Development Kit 8u151/NetBeans IDE 8.2
 Operating
 system: MS Windows 10
 Reference(s): Java 8 API - Oracle Documentation
 (http://docs.oracle.com/javase/8/docs/api/);
 Savitch, 6th Edition: Chapters 1 – 7, 9
 */
package awardmovie;

/**
 *
 * @author Jiacheng Sun
 */
public class RangeException extends Exception{
    private int bignum;
    
    public RangeException(){
        super("RangeException");
    }
    
    public RangeException(int num){
        super("RangeException");
        bignum = num;
    }
    
    public RangeException(String message)
    {
        super(message); 
    }
    
    public int getBignum(){
        return bignum;
    }
    
}
