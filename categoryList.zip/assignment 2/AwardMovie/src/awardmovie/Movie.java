/*
 Author: Jiacheng Sun
 E-mail: jzs375@psu.edu
 Course: CMPSC 221
 Assignment: Programming Assignment 2
 Due date: 2/27/2018
 File: AwardMovie.java
 Purpose: Java application that implements a driver to demonstrate the
 functionality of a base class (Movie) and its derived class
 (AwardWinningMovie)
 Compiler/IDE: Java SE Development Kit 8u151/NetBeans IDE 8.2
 Operating
 system: MS Windows 10
 Reference(s): Java 8 API - Oracle Documentation
 (http://docs.oracle.com/javase/8/docs/api/);
 Savitch, 6th Edition: Chapters 1 – 7, 9
*/
package awardmovie;

import java.util.Objects;

/**
 * This is a base class
 * @author Jiacheng Sun
 */

/**
 * 
 * Constructors 
 */
public class Movie {    //initialize five variables.
    private String title;
    private String rating;
    private String genre;
    private String director;
    private String star;
    
    public Movie(){     // default constructor
        title = "No title";
        rating = "No rating";
        genre = "No genre";
        director = "No director";
        star = "No star";
    }
    
    // constructor with 5 arguments 
    public Movie(String t, String r, String g, String d, String s){
        if(t == null || r == null || g == null || d == null || s ==null){
            System.out.println("ERROR CREATING MOVIE");
            System.exit(0);
        }
        else{
            title = t;
            rating = r;
            genre = g;
            director = d;
            star = s;
        }
    }
    
    // constructor for object
    public Movie(Movie originalObject){
        title = originalObject.title;
        rating = originalObject.rating;
        genre = originalObject.genre;
        director = originalObject.director;
        star = originalObject.star;
    }
    /**
     * set the arguments to movie
     * @param t title
     * @param r rating 
     * @param g genre
     * @param d director
     * @param s star
     */
    //set methods 
    public void setMovie(String t, String r, String g, String d, String s){
        setTitle(t);
        setRating(r);
        setGenre(g);
        setDirector(d);
        setStar(s);
    }
    /**
     * set t to title
     * @param t 
     */
    public void setTitle(String t){
        if (t == null)
        {
            System.out.println("Fatal Error setting title.");
            System.exit(0);
        }
        else{
            title = t;
        }
    }
    /**
     * set r to rating
     * @param r 
     */
    public void setRating(String r){
        if (r == null)
        {
            System.out.println("Fatal Error setting rating.");
            System.exit(0);
        }
        else
            rating = r;
    }
    /**
     * set g to genre
     * @param g 
     */
    public void setGenre(String g){
        if (g == null)
        {
            System.out.println("Fatal Error setting Genre.");
            System.exit(0);
        }
        else
            genre = g;
    }
    /**
     * set d to Director
     * @param d 
     */
    public void setDirector(String d){
        if (d.equals(""))
        {
            System.out.println("Fatal Error setting director.");
            System.exit(0);
        }
        else
            director = d;
    }
    /**
     * set s to star
     * @param s 
     */
    public void setStar(String s){
        if (s == null)
        {
            System.out.println("Fatal Error setting star.");
            System.exit(0);
        }
        else
            star = s;
    }
    
    /**
     * 
     * @return title
     */
    public String getTitle(){
        return title;
    }
    /**
     * 
     * @return rating 
     */
    public String getRating(){
        return rating;
    }
    /**
     * 
     * @return genre
     */
    public String getGenre(){
        return genre;
    }
    /**
     * 
     * @return director
     */
    public String getDirector(){
        return director;
    }
    /**
     * 
     * @return star
     */
    public String getStar(){
        return star;
    }
   
    /**
     *
     * @param otherObject
     * @return
     */
    @Override
    public boolean equals(Object otherObject){
        if (otherObject == null)
            return false;
        else if (getClass( ) != otherObject.getClass( ))
            return false;
        else
        {
            Movie otherMovie = (Movie)otherObject;
            return (title.equals(otherMovie.title)
                 && rating.equals(otherMovie.rating)
                 && star.equals(otherMovie.star)
                 && genre.equals(otherMovie.genre)
                 && director.equals(otherMovie.director));
        }
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 79 * hash + Objects.hashCode(this.title);
        hash = 79 * hash + Objects.hashCode(this.rating);
        hash = 79 * hash + Objects.hashCode(this.genre);
        hash = 79 * hash + Objects.hashCode(this.director);
        hash = 79 * hash + Objects.hashCode(this.star);
        return hash;
    }
    
    @Override
    /**
     * put it into string
     */
    public String toString( )
    {
        return ("Title     : " + title + "\nRating    : " + rating 
                + "\nGenre        : "
                + genre + "\nDirector  : " + director + "\nStar      : " + star
                + "\nAward     : " );
    }
    
}
