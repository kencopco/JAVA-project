/*
 Author: Jiacheng Sun
 E-mail: jzs375@psu.edu
 Course: CMPSC 221
 Assignment: Programming Assignment 2
 Due date: 2/27/2018
 File: AwardMovie.java
 Purpose: Java application that implements a driver to demonstrate the
 functionality of a base class (Movie) and its derived class
 (AwardWinningMovie)
 Compiler/IDE: Java SE Development Kit 8u151/NetBeans IDE 8.2
 Operating
 system: MS Windows 10
 Reference(s): Java 8 API - Oracle Documentation
 (http://docs.oracle.com/javase/8/docs/api/);
 Savitch, 6th Edition: Chapters 1 – 7, 9
 */
package awardmovie;
import java.util.*;
/**
 *
 * @author Jiacheng Sun
 */
public class AwardMovie {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        /**
         * initialize those objects 
         */
        AwardWinningMovie movie0 = new AwardWinningMovie(
        "Contact", "PG", "Mystery", "Robert Zemeckis", "Jodie Foster", 
          "Saturn Award for Best Performance by a Younger Actor/Actress", 1998);
        
        AwardWinningMovie movie1 = new AwardWinningMovie(
        "Driving Miss Daisy", "PG", "Drama", "Bruce Beresford", 
        "Morgan Freeman", "Oscar for Best Actress in a Leading Role", 1990);
        
        AwardWinningMovie movie2 = new AwardWinningMovie(
        "Forrest Gump", "PG-13", "Romance", "Robert Zemeckis", 
                "Tom Hanks", "Oscar for Best Actor in a Leading Role", 1995);
        
        AwardWinningMovie movie3 = new AwardWinningMovie(
        "La La Land", "PG-13", "Music", "Damien Chazelle", "Emma Stone", 
        "Oscar for Best Performance by an Actress in a Leading Role", 2017);
        
        AwardWinningMovie movie4 = new AwardWinningMovie(
        "Raiders of the Lost Ark", "PG", "Action", "Steven Spielberg", 
        "Harrison Ford", "Oscar for Best Film Editing", 1982);
        
        AwardWinningMovie movie5 = new AwardWinningMovie(
        "Sophie's Choice", "R", "Romance", "Alan J. Pakula", "Meryl Streep", 
                "Oscar for Best Actress in a Leading Role", 1983);
        
        AwardWinningMovie movie6 = new AwardWinningMovie(
        "Star Trek Into Darkness", "PG-13", "Sci-Fi", "J.J.Abrams", "Chris Pine"
                , "ASCAP Award for Top Box Office Films", 2014);
        
        AwardWinningMovie movie7 = new AwardWinningMovie(
        "The Queen", "PG-13", "Biography", "Stephen Frears", "Helen Mirren", 
        "Oscar for Best Performance by an Actress in a Leading Role", 2007);
        
        AwardWinningMovie movie8 = new AwardWinningMovie(
        "Titanic", "PG-13", "Romance", "James Cameron", "Leonardo DiCaprio", 
                "Oscar for Best Picture", 1998);
        
        AwardWinningMovie movie9 = new AwardWinningMovie(
        "X-Men", "PG-13", "Action", "Bryan Singer", "Hugh Jackman", 
                "Saturn Award for Best Actor", 2001);
        /**
         * initialize the array
         */
        AwardWinningMovie movies[] = {movie0, movie1, movie2, movie3, movie4
                , movie5, movie6,movie7,movie8,movie9}; 
        /**
         * a do-while loop check Y/N 
         * if Y(y) continue
         * if N(n) end
         */
       String othermovie = new String("Y");
        do{
        System.out.println("Movie titles are displayed alphabetically by "
                + "default.");
        System.out.println("To display them alphabetically by genre, type G "
                + "at the prompt.");
        System.out.println("Otherwise, simply press <Enter>.");
        System.out.println();
        
        System.out.println("Your Preference?");
        Scanner sort = new Scanner(System.in);
        
        if (sort.nextLine().equals("")){
        System.out.println();
        System.out.println("Selected award-winning movies: ");
        System.out.println("1) Contact");
        System.out.println("2) Driving Miss Daisy");
        System.out.println("3) Forrest Gump");
        System.out.println("4) La La Land");
        System.out.println("5) Raiders of the Lost Ark");
        System.out.println("6) Sophie's Choice");
        System.out.println("7) Star Trek Into Darkness");
        System.out.println("8) The Queen");
        System.out.println("9) Titanic");
        System.out.println("10) X-Men");
        System.out.println();
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        } // format alphabetically by title
        else{
            System.out.println();
            System.out.println("Selected award-winning movies by genre: ");
            System.out.println("Action: ");
            System.out.println("5) Raiders of the Lost Ark");
            System.out.println("10) X-Men");
            System.out.println("Biography: ");
            System.out.println("8) The Queen");
            System.out.println("Drama:");
            System.out.println("2) Driving Miss Daisy");
            System.out.println("Music: ");
            System.out.println("4) La La Land");
            System.out.println("Mystery: ");
            System.out.println("1) Contact");
            System.out.println("Romance: ");
            System.out.println("3) Forrest Gump");
            System.out.println("6) Sophie's Choice");
            System.out.println("9) Titanic");
            System.out.println("Sci-Fi ");
            System.out.println("7) Star Trek Into Darkness");
            //format alphabetically by genre
        }
        /**
         * get the choice for the movie 
         * handle the exception 1) not integer
         *                      2) out of range 
         */
        Scanner inputnum = new Scanner(System.in);
        System.out.println("Please enter the number of the movie you would "
                + "like to know more about: ");
        
        int test = 1;
        do{
        try{
        int n1 = inputnum.nextInt();
        if (n1<=0 || n1 > 10){
                throw new RangeException(n1); //throw out of range exception
        }
    
        System.out.println(movies[n1-1].toString());
        System.out.println();
        
        test = 2;
        }
        catch(RangeException e){
            System.out.println("Movie choice must within 1 - 10. "
                    + "Please try again."); //out of range exception
        }
        catch(Exception  e){
            System.out.println("Movie choice must be an integer. "
                    + "Please try again.");// nor integer exception
            inputnum.next();
        }
        }while(test == 1);
        
        
        System.out.println("Inquire about another movie (Y/N)?");
        System.out.println();
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        Scanner another = new Scanner(System.in);
        if (another.nextLine().equalsIgnoreCase("Y".trim())){
           othermovie = "Y";
        }
        else
        { othermovie = "N";
            System.out.println("Thanks for using our experimental database!");
        }
        }while(othermovie.equals("Y")); //check yes or no 
        
        
    }
    
}
