/*
 Author: Jiacheng Sun
 E-mail: jzs375@psu.edu
 Course: CMPSC 221
 Assignment: Programming Assignment 2
 Due date: 2/27/2018
 File: AwardMovie.java
 Purpose: Java application that implements a driver to demonstrate the
 functionality of a base class (Movie) and its derived class
 (AwardWinningMovie)
 Compiler/IDE: Java SE Development Kit 8u151/NetBeans IDE 8.2
 Operating
 system: MS Windows 10
 Reference(s): Java 8 API - Oracle Documentation
 (http://docs.oracle.com/javase/8/docs/api/);
 Savitch, 6th Edition: Chapters 1 – 7, 9
*/

package awardmovie;

import java.util.Objects;

/**
 * This is a derived class 
 * @author Jiacheng Sun
 */
public class AwardWinningMovie extends Movie{ 
    
    private String awardTitle;
    private int awardYear; // initialize two new variables 
    /**
     * constructors 
     */
    public AwardWinningMovie () {
        super( );
        awardTitle = null;
        awardYear = 0;
    }
    /**
     * 
     */
    public AwardWinningMovie(String t, String r, String g, String d,
            String s, String aT, int aY){
        super(t, r, g, d, s);
        if(!(aT == null) && aY!=0){
            awardTitle = aT;
            awardYear = aY;
        }
        else{
            System.out.println(
                       "Fatal Error: creating an illegal Award Winning Movie.");
            System.exit(0);
        }
    }
    
    public AwardWinningMovie(AwardWinningMovie originalObject){
        super(originalObject);
        awardTitle = originalObject.awardTitle;
        awardYear = originalObject.awardYear;
    }
    /**
     * set awardtitle 
     * @param aT 
     */
    public void setAwardTitle(String aT){
        if (aT != null)
        {
            awardTitle = aT;
        }
        else
        {
            System.out.println("Fatal Error: No title entry.");
            System.exit(0);
        }
    }
    /**
     * set award year
     * @param aY 
     */
    public void setAwardYear(int aY){
        if (aY != 0)
        {
            awardYear = aY;
        }
        else
        {
            System.out.println("Fatal Error: No year entry.");
            System.exit(0);  
        }
    }
    /**
     * 
     * @return awardtitle
     */
    public String getAwardTitle(){
        return awardTitle;
    }
    /**
     * 
     * @return awardyear
     */
    public int getAwardYear(){
        return awardYear;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 89 * hash + Objects.hashCode(this.awardTitle);
        hash = 89 * hash + this.awardYear;
        return hash;
    }
    
    @Override
    public boolean equals(Object otherObject){
        if (otherObject == null)
            return false;
        else if (getClass( ) != otherObject.getClass( ))
            return false;
        else
        {
            AwardWinningMovie otherMovie = (AwardWinningMovie)otherObject;
            return (super.equals(otherMovie)
                 && awardTitle.equals(otherMovie.awardTitle)
                 && awardYear == otherMovie.awardYear);
        }
    }
    
    @Override
    /**
     * put it into string 
     */
    public String toString(){
        return ("Title     : " + getTitle() 
                + "\nRating    : " + getRating() 
                +"\nGenre     : " + getGenre() 
                + "\nDirector  : " + getDirector() 
                + "\nStar      : " + getStar()
                + "\nAward     : " + awardTitle + ", " + awardYear);
    }
}


