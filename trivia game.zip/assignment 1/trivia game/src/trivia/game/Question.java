/*
 * Author:          Jiacheng Sun
 * E-mail:          jzs375@psu.edu
 * Course:          CMPSC 221
 * Assignment:      Programming Assignment 1
 * Due Date:        2/6/2018
 * File:            TriviaGame.java
 * Purpose:         Java application that implements a simple sci-fi trivia game
 * Compiler/IDE:    Java SE Deveopment Kit 8u151/Netbeans IDE 8.2
 * Operation system:MS Windows 10
 * Reference(s):    Java 8 API - Oracle Documentation
 *                  (http://docs.oracle.com/javase/8/docs/api/);
 */
package trivia.game;

/**
 *
 * @author Jiacheng Sun
 */

/**
 * set up a default constructor of all the questions and answers
 */
public class Question {
String     q0 = ("What's the main character's full name in ONE PIECE?"),
           q1 = ("What's the main character's full name in NARUTO?"),
           q2 = ("What's Edugawa Conan's real name?"),
           q3 = ("Which king is the saber in FATE-STAY NIGHT"),
           q4 = ("What's the main character's full name in BLEACH?"),
           q5 = ("What's the main character's full name in EVA?"),
           q6 = ("What's Boruto's father's name?"),
           q7 = ("What is the password of Mouri Kogorou's laptop"),
           q8 = ("Which alien is Suzumiya Haruhi's friend?"),
           q9 = ("What's the main character's full name in monogatari series");
    
String     a0 = ("MONKEY D. LUFFY"),
           a1 = ("UZUMAKI NARUTO"),
           a2 = ("KUDOU SHINICHI"),
           a3 = ("KING ARTHUR"),
           a4 = ("KUROSAKI ICHIGO"),
           a5 = ("IKARI SHINJI"),
           a6 = ("UZUMAKI NARUTO"),
           a7 = ("5563"),
           a8 = ("NAGATO YUKI"),
           a9 = ("ARARAGI KOYOMI");
       

}
