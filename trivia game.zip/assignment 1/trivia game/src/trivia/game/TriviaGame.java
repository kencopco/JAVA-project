/*
 * Author:          Jiacheng Sun
 * E-mail:          jzs375@psu.edu
 * Course:          CMPSC 221
 * Assignment:      Programming Assignment 1
 * Due Date:        2/6/2018
 * File:            TriviaGame.java
 * Purpose:         Java application that implements a simple sci-fi trivia game
 * Compiler/IDE:    Java SE Deveopment Kit 8u151/Netbeans IDE 8.2
 * Operation system:MS Windows 10
 * Reference(s):    Java 8 API - Oracle Documentation
 *                  (http://docs.oracle.com/javase/8/docs/api/);
 */
package trivia.game;


import javax.swing.JOptionPane;
import java.util.Random;
/**
 *
 * @author Jiacheng Sun 
 */
public class TriviaGame {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    /**
     * the application of default constructor 
     * and put those elements in the constructor into array
     */
        Question Q = new Question();
        String[] question = {Q.q0, Q.q1, Q.q2, Q.q3, Q.q4, Q.q5, Q.q6, Q.q7, 
                            Q.q8, Q.q9}; //question array
        String[] answer = {Q.a0, Q.a1, Q.a2, Q.a3, Q.a4, Q.a5, Q.a6, Q.a7, 
                           Q.a8, Q.a9}; //answer array
        
        /**
         *  use method in JOptionPane
         *  use showMessageDialog to show the information 
         * @param      displayed message,title, icon type
         * 
         *  use showInputDialog to get the input
         *  @param      displayed message,title, icon type
         *  @return     string type message that user put in
         * 
         *  use showConfirmDialog to get user's choice (play or not)
         * @param      displayed message,title, icon type
         *  @return     int type, if yes 0, no 1, cancel 2.
         */
        JOptionPane.showMessageDialog(null, "welcome to the anime knowledge test!","Anime Test", JOptionPane.INFORMATION_MESSAGE); 
                                        //show the welcome message
                                        
        String userinput;        //initialize the user's input
        int n;                      //initialize serial number that will be used in array
        boolean check = true;           //initialize the condition of the while loop 
        while(check == true){
            Random order = new Random();       
            n = order.nextInt(10);      //use to find the random elements in question array
            userinput = 
                JOptionPane.showInputDialog(null, question[n],"Anime Test", JOptionPane.QUESTION_MESSAGE);
                  
            
            if (userinput == null){
                int c = 
                    JOptionPane.showConfirmDialog(null, "CONTINUE?","Anime Test", JOptionPane.YES_NO_CANCEL_OPTION);
                if (c == 0){
                check = true;                                                   //press yes, and continue to play
                }
                else{
                check = false;                                                  //press no or cancel, stop playing
                }                                                    
            }                                                        
            else if(!userinput.toUpperCase().trim().equals(answer[n])){      //incorrect and no answer condition
                JOptionPane.showMessageDialog(null, "INCORRECT!","Anime Test",JOptionPane.INFORMATION_MESSAGE);
                int c = 
                    JOptionPane.showConfirmDialog(null, "CONTINUE?","Anime Test", JOptionPane.YES_NO_CANCEL_OPTION);
                if (c == 0){
                check = true;                                                   //press yes, and continue to play
                }
                else{
                check = false;                                                  //press no or cancel, stop playing
                }
            }                                                    
                                                                
                                                                
            else if(userinput.toUpperCase().trim().equals(answer[n])){                 // correct condition, transfer to uppercase, ignore the leading and tailing space
                JOptionPane.showMessageDialog(null, "CORRECT!","Anime Test",JOptionPane.INFORMATION_MESSAGE);
                int c = 
                    JOptionPane.showConfirmDialog(null, "CONTINUE?","Anime Test", JOptionPane.YES_NO_CANCEL_OPTION);
                if (c == 0){
                check = true;                                    //press yes and continue to play
                }
                else{
                check = false;                                   //press no or cancel, stop playing
                }
            }
            
                                                      
        
        }
          
            
        
        JOptionPane.showMessageDialog(null, "Thank you for playing! See you!","Anime Test", JOptionPane.INFORMATION_MESSAGE);
    }                                                                           //goodbye message
    
}
