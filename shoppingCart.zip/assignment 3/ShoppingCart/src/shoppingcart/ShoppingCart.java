/*
Author: Jiacheng Sun
E-mail: jzs375@psu.edu
Course: CMPSC 221
Assignment: Programming Assignment 3
Due date: 4/2/2018
File: ShoppingCart.java
Purpose: Java application that implements an online store complete
with shopping cart and check out procedure
Compiler/IDE: Java SE Development Kit 8u151/NetBeans IDE 8.2
Operating
system: MS Windows 10
Reference(s): Java 8 API - Oracle Documentation
(http://docs.oracle.com/javase/8/docs/api/)
*/
package shoppingcart;

/**
 *
 * @author kensu
 */
import java.util.Scanner;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
public class ShoppingCart {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //read from the file
        Scanner inputStream = null;
        try{
            inputStream = 
                    new Scanner(new FileInputStream("goodslist.txt"));
        }
        catch(FileNotFoundException e)
        {
            System.out.println("File goodslist.txt was not found");
            System.out.println("or could not be opened.");
            System.exit(0);
        }
        ArrayList<Item>inventory = new ArrayList<>(15);     //initialize inventory
        ArrayList<Item>shoppingCart = new ArrayList<>();    //initialize shopping cart
        Item Good = new Item();
        
        // create inventory
        for (int i =0; i < 15; i++){
        int num = Integer.parseInt(inputStream.nextLine());
        String name = inputStream.nextLine();
        String category = inputStream.nextLine();
        double price = Double.parseDouble(inputStream.nextLine());
        int quantity = Integer.parseInt(inputStream.nextLine());
        Item good  = new Item(num,name,category,price,quantity);
        inventory.add(good);
        }
        System.out.println("Welcome to Amazon online!");
        System.out.println("");
        int a = 1;
        while(a != 0){  //keep running the loop until check out(a =0)
        // create level one menu
        System.out.println("Choose an option.");
        System.out.println("1) Create empty shopping cart");
        System.out.println("2) Add item to shopping cart");
        System.out.println("3) Remove item from shopping cart");
        System.out.println("4) Check out");
        System.out.println("");
        Scanner choiceOP = new Scanner(System.in);
        
        //exception handle for choice 1
        int c1 = 0;
        int test1 = 1;
        do{
        try{
            System.out.println("Your choice?");
            c1 = choiceOP.nextInt();
            if (c1< 1 || c1 > 4){
                throw new RangeException(c1); //throw out of range exception
            }
            test1 = 2;
        }
        catch(RangeException e){
            System.out.println("choice must be an integer within 1 - 4");
        }
        catch(Exception e){
            System.out.println("choice must be an integer within 1 - 4");
            choiceOP.next();
        }
        }while (test1 == 1);
        
        switch (c1) {           
            case 1: //create empty shopping cart
                System.out.println("Shopping Cart created!");
                shoppingCart.clear();
                break;
                
            case 2: //add items create level two menu
                System.out.println("Choose a category.");
                System.out.println("1) Consoles");
                System.out.println("2) Books");
                System.out.println("3) Music");
                Scanner choiceCAT = new Scanner(System.in);
                
                // exception handle for choice 2
                int c2 = 0;
                int test2 = 1;
                do{
                try{
                System.out.println("Your choice?");
                c2 = choiceCAT.nextInt();
                if (c2<=0 || c2 > 3){
                    throw new RangeException(c2); //throw out of range exception
                    }
                test2 = 2;
                }
                catch(RangeException e){
                System.out.println("choice must be an integer within 1 - 3");
                }
                catch(Exception e){
                System.out.println("choice must be an integer within 1 - 3");
                choiceCAT.next();
                }
                }while (test2 == 1);
                
                int c3 = 0;
                int test3 = 1;
                switch(c2){        // create level three menu
                    case 1: //console
                        System.out.println("100 PS4 pro               $399.00");
                        System.out.println("101 XBOX ONE S            $249.00");
                        System.out.println("102 Nintendo Switch       $299.00");
                        System.out.println("103 3DS                   $189.49");
                        System.out.println("104 WiiU                  $269.00");
                        System.out.println("Enter the number of the item you wish to add");
                        Scanner choiceGood100 = new Scanner(System.in);
                        // exception handle for choice 3
                        do{
                        try{
                            System.out.println("Your choice?");
                            c3 = choiceGood100.nextInt();
                            if (c3< 100|| c3 >104){
                                throw new RangeException(c3); //throw out of range exception
                            }
                            test3 = 2;
                        }
                        catch(RangeException e){
                            System.out.println("choice must be an integer within 100 - 104");
                        }
                        catch(Exception e){
                            System.out.println("choice must be an integer within 100 - 104");
                            choiceGood100.next();
                        }
                        }while (test3 == 1);
                        //handle the quantity++ case
                        Good = inventory.get(c3-100);
                        if (shoppingCart.isEmpty()){
                            shoppingCart.add(Good);
                        }
                        else{
                            shoppingCart.add(Good);
                            for (int i = 0; i < shoppingCart.size()-1;i++){    //quantity++
                                if(shoppingCart.get(i).equals(Good)){
                                   shoppingCart.get(i).setQuantity(shoppingCart.get(i).getQuantity()+1);
                                   shoppingCart.remove(shoppingCart.size()-1);
                                }
                            }
                        }
                        
                        System.out.println("Your choice " + Good.getName() + " "
                                + "has been add to the shopping cart");
                        for (Item entry : shoppingCart){
                            System.out.println(entry.toString());
                        }
                        break;
                        
                    case 2:  //books
                        System.out.println("200 The Stranger                $8.67");
                        System.out.println("201 Goodnight Moon              $5.89");
                        System.out.println("202 Physics for Poets           $29.07");
                        System.out.println("203 Doctor Who: Deep Time       $8.47");
                        System.out.println("204 Doctor Who: Heart of Stone  $9.99");
                        System.out.println("Enter the number of the item you wish to add");
                        Scanner choiceGood200 = new Scanner(System.in);
                        
                        //exception handle
                        c3 = 0;
                        test3 = 1;
                        do{
                        try{
                            System.out.println("Your choice?");
                            c3 = choiceGood200.nextInt();
                            if (c3< 200|| c3 >204){
                                throw new RangeException(c3); //throw out of range exception
                            }
                            test3 = 2;
                        }
                        catch(RangeException e){
                            System.out.println("choice must be an integer within 200 - 204");
                        }
                        catch(Exception e){
                            System.out.println("choice must be an integer within 200 - 204");
                            choiceGood200.next();
                        }
                        }while (test3 == 1);
                        
                        Good = inventory.get(c3-195);
                        if (shoppingCart.isEmpty()){
                            shoppingCart.add(Good);
                        }
                        else{
                            shoppingCart.add(Good);
                            for (int i = 0; i < shoppingCart.size()-1;i++){    //quantity++
                                if(shoppingCart.get(i).equals(Good)){
                                   shoppingCart.get(i).setQuantity(shoppingCart.get(i).getQuantity()+1);
                                   shoppingCart.remove(shoppingCart.size()-1);
                                }
                            }
                        }
                        
                        System.out.println("Your choice " + Good.getName() + " "
                                + "has been add to the shopping cart");
                        for (Item entry : shoppingCart){
                            System.out.println(entry.toString());
                        }
                        break;
                        
                    case 3:  //music
                        System.out.println("300 Hamilton                  $18.99");
                        System.out.println("301 Prey For The Wicked       $9.49");
                        System.out.println("302 The Tree of Forgiveness   $9.49");
                        System.out.println("303 When Legends Rise         $11.99");
                        System.out.println("304 Reputation                $13.40");
                        System.out.println("Enter the number of the item you wish to add");
                        System.out.println("Your choice:");
                        Scanner choiceGood300 = new Scanner(System.in);
                        //exception handle
                        c3 = 0;
                        test3 = 1;
                        do{
                        try{
                            System.out.println("Your choice?");
                            c3 = choiceGood300.nextInt();
                            if (c3< 300|| c3 >304){
                                throw new RangeException(c3); //throw out of range exception
                            }
                            test3 = 2;
                        }
                        catch(RangeException e){
                            System.out.println("choice must be an integer within 300 - 304");
                        }
                        catch(Exception e){
                            System.out.println("choice must be an integer within 300 - 304");
                            choiceGood300.next();
                        }
                        }while (test3 == 1);
                        
                        Good = inventory.get(c3-290);
                        if (shoppingCart.isEmpty()){
                            shoppingCart.add(Good);
                        }
                        else{
                            shoppingCart.add(Good);
                            for (int i = 0; i < shoppingCart.size()-1;i++){    //quantity++
                                if(shoppingCart.get(i).equals(Good)){
                                   shoppingCart.get(i).setQuantity(shoppingCart.get(i).getQuantity()+1);
                                   shoppingCart.remove(shoppingCart.size()-1);
                                }
                            }
                        }
                        
                        System.out.println("Your choice " + Good.getName() + " "
                                + "has been add to the shopping cart");
                        for(Item entry : shoppingCart) 
                        {
                            System.out.println(entry.toString());
                        }
                        break;
                        
                    default: //error
                        System.out.println("Error input");
                        System.exit(0);
                        break;
                }
                break;
                
            case 3: //remove item
                System.out.println("Display the current contents of the shopping cart ...");
                for (Item entry : shoppingCart){
                    System.out.println(entry.toString());
                }
                System.out.println("");
                System.out.println("Enter the number of the item you wish to remove.");
                Scanner choiceRemove = new Scanner(System.in);
                //handle exception
                int remove = 0;
                int test4 = 1;
                do{
                try{
                    System.out.println("Your choice?");
                    remove = choiceRemove.nextInt();
                    if (remove != 100 && remove != 101 && remove != 102 
                            && remove != 103 && remove != 104 &&
                        remove != 200 && remove != 201 && remove != 202 
                            && remove != 203 && remove != 204 &&
                        remove != 300 && remove != 301 && remove != 302 
                            && remove != 303 && remove != 304){
                        throw new RangeException(remove); //throw out of range exception
                    }
                    test4 = 2;
                    }
                    catch(RangeException e){
                        System.out.println("choice must be an integer in the menu");
                    }
                    catch(Exception e){
                        System.out.println("choice must be an integer in the menu");
                        choiceRemove.next();
                    }                       
                }while (test4 == 1);
                
                if (remove < 200)
                    Good = inventory.get(remove-100);
                else if(remove<300)
                    Good = inventory.get(remove - 195);
                else
                    Good = inventory.get(remove - 290);
                if (shoppingCart.isEmpty()){
                    System.out.println("Your Cart is empty");
                }
                else{
                        for (int i = 0; i < shoppingCart.size();i++){    //quantity++
                            if(shoppingCart.get(i).equals(Good)){
                               shoppingCart.get(i).getQuantity();
                               if(shoppingCart.get(i).getQuantity()==1)
                                   shoppingCart.remove(i);
                               else if(shoppingCart.get(i).getQuantity()>1){
                                   shoppingCart.get(i).setQuantity(shoppingCart.get(i).getQuantity()-1);
                               }
                            }  
                        }
                }
                
                System.out.println("#" + remove + "have been removed from "
                                + "the shopping cart");
                System.out.println("Displaying the shopping cart...");
                for (Item entry : shoppingCart){
                    System.out.println(entry.toString());
                }
                break;
                
            case 4: //check out
                System.out.println("");
                System.out.println("ORDER SUMMARY");
                System.out.println("");
                double total = 0.00;
                for (Item entry : shoppingCart){
                    System.out.println(entry.toString());
                    System.out.println("");
                    total = total + entry.getPrice()*entry.getQuantity();
                }
                //calculate the total value
                System.out.println("Order Total:$   "+ total );
                System.out.println("How do you wish to pay for your order?");
                System.out.println("(Enter 1 to charge to credit card on file"
                        + " or 2 to charge to new credit card.):");
                System.out.println("");
                Scanner choicePay = new Scanner(System.in);
                
                int c5 = 0;
                int test5 = 1;
                do{
                try{
                    System.out.println("Your choice?");
                    c5 = choicePay.nextInt();
                            if (c5< 1 || c5 >2){
                                throw new RangeException(c5); //throw out of range exception
                            }
                            test5 = 2;
                        }
                        catch(RangeException e){
                            System.out.println("choice must be 1 or 2");
                        }
                        catch(Exception e){
                            System.out.println("choice must be 1 or 2");
                            choicePay.next();
                        }
                        }while (test5 == 1);
                
                System.out.println("");
                String cardName = new String();
                String cardType = new String();
                String cardNum = new String();
                String cardDate = new String();
                switch(c5){
                    case 1:
                        cardName = "Jiacheng Sun";
                        cardType = "Visa";
                        cardNum = "4737028979847444";
                        cardDate = "01/2020";
                        break;
                    case 2:
                        System.out.println("Please enter your payment information.");
                        System.out.println("");
                        System.out.println("Card holder name: ");
                        Scanner cardname = new Scanner(System.in);
                        cardName = cardname.nextLine();
                        System.out.println("Credit card type (e.g.,MasterCard): ");
                        Scanner cardtype = new Scanner(System.in);
                        cardType = cardtype.nextLine();
                        System.out.println("Credit card number (e.g.,5201345098756420): ");
                        Scanner cardnum = new Scanner(System.in);
                        
                        test3 = 1;
                        do{
                        try{
                            cardNum = cardnum.nextLine();
                            if (cardNum.length()!=16){
                                throw new RangeException(cardNum.length()); //throw out of range exception
                            }
                            test3 = 2;
                        }
                        catch(RangeException e){
                            System.out.println("choice must be 16 digits integer");
                            System.out.println("Try again.");
                        }
                        catch(Exception e){
                            System.out.println("choice must be 16 digits integer");
                            System.out.println("Try again");
                            cardnum.next();
                        }
                        }while (test3 == 1);
                        
                        System.out.println("Expiration date (e.g.,10/2016): ");
                        Scanner carddate = new Scanner(System.in);
                        cardDate = carddate.nextLine();
                        break;
                }
                System.out.println("Credit payment summary:");
                System.out.println("");
                System.out.println(" Customer name:  "+ cardName);
                System.out.println("Payment amount: $ " + total);
                System.out.println("     Card type:  " + cardType);
                System.out.println("   Card number:  ************" +cardNum.charAt(12)
                        +cardNum.charAt(13)+cardNum.charAt(14)+cardNum.charAt(15));
                System.out.println("      Exp date:  "+ cardDate);
                a = 0;
                break;
        }
        }
        System.out.println("");
        System.out.println("Thanks for shopping at Amazon Online.");
        System.out.println("Please come back soon!");
    }


    
    
}
