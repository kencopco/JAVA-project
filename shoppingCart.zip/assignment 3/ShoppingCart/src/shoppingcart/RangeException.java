/*
Author: Jiacheng Sun
E-mail: jzs375@psu.edu
Course: CMPSC 221
Assignment: Programming Assignment 3
Due date: 4/2/2018
File: ShoppingCart.java
Purpose: Java application that implements an online store complete
with shopping cart and check out procedure
Compiler/IDE: Java SE Development Kit 8u151/NetBeans IDE 8.2
Operating
system: MS Windows 10
Reference(s): Java 8 API - Oracle Documentation
(http://docs.oracle.com/javase/8/docs/api/)
*/
package shoppingcart;

/**
 *THIS IS EXCEPTION CLASS
 * @author kensu
 */
public class RangeException extends Exception{
    private int bignum;
    private String num;
    
    public RangeException(){
        super("RangeException");
    }
    
    public RangeException(int num){
        super("RangeException");
        bignum = num;
    }
    
    public RangeException(String message)
    {
        super(message); 
        num = message;
    }
    
    public int getBignum(){
        return bignum;
    }
    
    public String getNum(){
        return num;
    }
}
