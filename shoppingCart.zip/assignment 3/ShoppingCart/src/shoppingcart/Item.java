/*
Author: Jiacheng Sun
E-mail: jzs375@psu.edu
Course: CMPSC 221
Assignment: Programming Assignment 3
Due date: 4/2/2018
File: ShoppingCart.java
Purpose: Java application that implements an online store complete
with shopping cart and check out procedure
Compiler/IDE: Java SE Development Kit 8u151/NetBeans IDE 8.2
Operating
system: MS Windows 10
Reference(s): Java 8 API - Oracle Documentation
(http://docs.oracle.com/javase/8/docs/api/)
*/
package shoppingcart;

import java.util.Objects;

/**
 *
 * @author kensu
 */
public class Item {         //initialize five variables
    private int number;
    private String name;
    private String category;
    private double price;
    private int quantity;
    
    public Item(){          // default constructors
        number = 0;
        name = "";
        category = "";
        price = 0.00;
        quantity = 0;
    }
    
    //constructor with 5 variables
    public Item(int num, String n, String cat, double p, int q){
        if (num == 0 || n == null || cat == null || p == 0 || q == 0 ){
            System.out.println("ERROR CREATING ITEM");
            System.exit(0);
        }
        else{
            number = num;
            name = n;
            category = cat;
            price = p;
            quantity = q;
        }
    }
    
    //constructor for object
    public Item(Item originalObject){
        number = originalObject.number;
        name = originalObject.name;
        category = originalObject.category;
        price = originalObject.price;
        quantity = originalObject.quantity;
    }
    
    /**
     * set the arguments to Item
     * @param num number
     * @param n name 
     * @param cat category
     * @param p price
     * @param q quantity
     */
    //set methods 
    public void SetItem(int num, String n, String cat, double p, int q){
        setNumber(num);
        setName(n);
        setCategory(cat);
        setPrice(p);
        setQuantity(q);
    }
    
    /**
     * set num to number
     * @param num
     */
    public void setNumber(int num){
        if (num == 0)
        {
            System.out.println("Fatal Error setting title.");
            System.exit(0);
        }
        else{
            number = num;
        }
    }
    
    /**
     * set n to name
     * @param n 
     */
    public void setName(String n){
        if (n == null)
        {
            System.out.println("Fatal Error setting name.");
            System.exit(0);
        }
        else{
            name = n;
        }
    }
    
    /**
     * set cat to category
     * @param cat
     */
    public void setCategory(String cat){
        if (cat == null)
        {
            System.out.println("Fatal Error setting category.");
            System.exit(0);
        }
        else{
            category = cat;
        }
    }
    
    /**
     * set p to price
     * @param p 
     */
    public void setPrice(double p){
        if (p == 0)
        {
            System.out.println("Fatal Error setting price.");
            System.exit(0);
        }
        else{
            price = p;
        }
    }
    
        /**
     * set q to quantity
     * @param q 
     */
    public void setQuantity(int q){
        if (q == 0)
        {
            System.out.println("Fatal Error setting quantity.");
            System.exit(0);
        }
        else{
            quantity = q;
        }
    }
    
    /**
     * 
     * @return number
     */
    public int getNumber(){
        return number;
    }
    
    /**
     * 
     * @return name
     */
    public String getName(){
        return name;
    }
    
    /**
     * 
     * @return category
     */
    public String getCategory(){
        return category;
    }
    
    /**
     * 
     * @return price
     */
    public double getPrice(){
        return price;
    }
    
    /**
     * 
     * @return quantity
     */
    public int getQuantity(){
        return quantity;
    }
    
    /**
     *
     * @param otherObject
     * @return
     */
    @Override
    public boolean equals(Object otherObject){
        if (otherObject == null)
            return false;
        else if (getClass( ) != otherObject.getClass( ))
            return false;
        else
        {
            Item otherItem = (Item)otherObject;
            return (number == otherItem.number
                 && name.equals(otherItem.name)
                 && category.equals(otherItem.category)
                 && price == otherItem.price
                 && quantity == otherItem.quantity);
        }
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 23 * hash + this.number;
        hash = 23 * hash + Objects.hashCode(this.name);
        hash = 23 * hash + Objects.hashCode(this.category);
        hash = 23 * hash + (int) (Double.doubleToLongBits(this.price) ^ 
                (Double.doubleToLongBits(this.price) >>> 32));
        hash = 23 * hash + this.quantity;
        return hash;
    }
    
    @Override
    // nicely format them into string
    public String toString(){
        return("Number     : " + number + "\n"
             + "Name       : " + name 
           + "\n"
             + "Category   : " + category + "\n"
             + "Price      : $" + price 
           + "\n"
             + "Quantity   : " + quantity +"\n"
                );
    }
}
