/*
 Author: Jiacheng Sun
 E-mail: jzs375@psu.edu
 Course: CMPSC 221
 Assignment: Programming Assignment 4
 Due date: 4/24/2018
 File: Question.java
 Purpose: Java application that implements a simple sci-fi trivia game
 with a GUI
 Compiler/IDE: Java SE Development Kit 8u151/NetBeans IDE 8.2
 Operating
 system: MS Windows 10
 Reference(s): Java 8 API - Oracle Documentation
 (http://docs.oracle.com/javase/8/docs/api/);
 Savitch, 6th Edition: Chapters 1 – 6, 14, 17
 */
package triviagamegui;

/**
 *
 * @author Jiacheng Sun 
 */
public class Question {
    private String question;
    private String answer;
    private int pointValue;
    
    /**
     * default constructor
     */
    public Question(){
        question = "no question";
        answer = "no answer";
        pointValue = 0;
        
    }
    /**
     * constructor for 3 parameter
     * @param q
     * @param a
     * @param pv 
     */
    public Question(String q, String a, int pv){
        if(q == null || a == null || pv == 0){
            System.out.println("ERROR CREATING MOVIE");
            System.exit(0);
        }
        else {
            question = q;
            answer = a;
            pointValue = pv;
        }     
    }
    
    public Question (Question originalobject){
        question = originalobject.question;
        answer = originalobject.answer;
        pointValue = originalobject.pointValue;
    }
    /**
     * Set method for question, answer and pointvalue
     * @param q
     * @param a
     * @param pv 
     */
    public void SetQuestion (String q, String a, int pv){
        setQ(q);
        setA(a);
        setPV(pv);
    }
    
    public void setQ(String q){
        if (q == null)
        {
            System.out.println("Fatal Error setting title.");
            System.exit(0);
        }
        else
            question = q;
    }
    
    public void setA(String a){
        if (a == null)
        {
            System.out.println("Fatal Error setting title.");
            System.exit(0);
        }
        else
            answer = a;
    }
    
    public void setPV(int pv){
        if (pv == 0)
        {
            System.out.println("Fatal Error setting title.");
            System.exit(0);
        }
        else
            pointValue = pv;
    }
    /**
     * return method for question, answer and pointvalue
     * @return 
     */
    public String getQ(){
        return question;
    }
    
    public String getA(){
        return answer;
    }
    
    public int getPV(){
        return pointValue;
    }
}


