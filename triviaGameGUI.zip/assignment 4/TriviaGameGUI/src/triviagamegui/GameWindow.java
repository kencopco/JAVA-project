/*
 Author: Jiacheng Sun
 E-mail: jzs375@psu.edu
 Course: CMPSC 221
 Assignment: Programming Assignment 4
 Due date: 4/24/2018
 File: GameWindow.java
 Purpose: Java application that implements a simple sci-fi trivia game
 with a GUI
 Compiler/IDE: Java SE Development Kit 8u151/NetBeans IDE 8.2
 Operating
 system: MS Windows 10
 Reference(s): Java 8 API - Oracle Documentation
 (http://docs.oracle.com/javase/8/docs/api/);
 Savitch, 6th Edition: Chapters 1 – 6, 14, 17
 */
package triviagamegui;

/**
 *
 * @author Jiacheng Sun
 */
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.GridLayout;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Random;

public class GameWindow extends JFrame implements ActionListener{
    public static final int WIDTH = 500; 
    public static final int HEIGHT = 300;
    private JTextField ans;
    private JLabel checkMessage;
    private JLabel quesMessage;
    private int i =0;
    private int j = 0;
    private int scores = 0;
    private ArrayList<Question> QList = new ArrayList<>(10);
    private Random order = new Random();
    /**
     * construct the arraylist for 10 questions.
     */
    public GameWindow( ){
        super("Anime Trivia Game");
        
        Question Q0 = new Question(
                "What's the main character's full name in ONE PIECE?",
                "MONKEY D. LUFFY",1);
        Question Q1 = new Question(
                "What's the main character's full name in NARUTO?",
                "UZUMAKI NARUTO",1);
        Question Q2 = new Question("What's Edugawa Conan's real name?",
                "KUDOU SHINICHI",1);
        Question Q3 = new Question("Which king is the saber in FATE-STAY NIGHT",
                "KING ARTHUR",2);
        Question Q4 = new Question(
                "What's the main character's full name in BLEACH?",
                "KUROSAKI ICHIGO",1);
        Question Q5 = new Question(
                "What's the main character's full name in EVA?","IKARI SHINJI",1);
        Question Q6 = new Question("What's Boruto's father's name?",
                "UZUMAKI NARUTO",2);
        Question Q7 = new Question(
                "What is the password of Mouri Kogorou's laptop","5563",3);
        Question Q8 = new Question("Which alien is Suzumiya Haruhi's friend?",
                "NAGATO YUKI",3);
        Question Q9 = new Question(
                "What's the main character's full name in monogatari series",
                "ARARAGI KOYOMI",1);
        QList.add(Q0);
        QList.add(Q1);
        QList.add(Q2);
        QList.add(Q3);
        QList.add(Q4);
        QList.add(Q5);
        QList.add(Q6);
        QList.add(Q7);
        QList.add(Q8);
        QList.add(Q9);
        
        
        
        
        /**
         * generate first serial number and first random question.
         */
        i = i + 1;
        j = order.nextInt(10);    
            
            
        setSize(WIDTH, HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // close option
        getContentPane().setBackground(Color.BLUE);
        
        setLayout(new GridLayout(5,1));     // 5 * 1 layout
        
        JPanel check = new JPanel();        // answer and scores line
        checkMessage = new JLabel("");
        check.add(checkMessage);
        add(check);
        check.setBackground(Color.YELLOW);
        
        JPanel ques = new JPanel();         // second question line
        quesMessage = new JLabel("Question "+ i +":" + QList.get(j).getQ());
        ques.add(quesMessage);
        add(ques);
        
        JPanel input = new JPanel();        // input Jtextfield
        ans = new JTextField("Your answer?", 30);
        input.add(ans);
        add(input);
        
        JPanel tip = new JPanel();          // the label
        JLabel tipMessage = new JLabel("Click to check answer:");
        tip.add(tipMessage);
        add(tip);
        
        JPanel subPanel = new JPanel();     // the button 
        JButton submitButton = new JButton("Submit");
        submitButton.addActionListener(this);
        subPanel.add(submitButton);
        add(subPanel);
        
    }
    
    public void actionPerformed(ActionEvent e) 
    {
        String actionCommand = e.getActionCommand( );

        if (actionCommand.equals("Submit")){
            //check answer
            if(ans.getText().toUpperCase().trim().equals(QList.get(j).getA())) {
                scores = scores + QList.get(j).getPV();
                checkMessage.setText("That is correct! Your score is " + scores );
            }
            else
                checkMessage.setText("Wrong! The correct answer is " 
                        + QList.get(j).getA() + " Your score is " + scores);
        
        // to change and reset the content on the window.
        i = i + 1;
        j = order.nextInt(10);
        quesMessage.setText("Question "+ i +":" + QList.get(j).getQ());
        ans.setText("Your answer?");
        }
        
    } 
}
